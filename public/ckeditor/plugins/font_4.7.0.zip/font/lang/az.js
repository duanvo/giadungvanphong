/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'az', {
	fontSize: {
		label: 'Şrift ölçüsü',
		voiceLabel: 'Şrift ölçüsü',
		panelTitle: 'Şrift ölçüsü'
	},
	label: 'Şrift',
	panelTitle: 'Şrift',
	voiceLabel: 'Şrift'
} );
