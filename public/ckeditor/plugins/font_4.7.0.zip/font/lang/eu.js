/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'eu', {
	fontSize: {
		label: 'Tamaina',
		voiceLabel: 'Letra-tamaina',
		panelTitle: 'Letra-tamaina'
	},
	label: 'Letra-tipoa',
	panelTitle: 'Letra-tipoaren izena',
	voiceLabel: 'Letra-tipoa'
} );
